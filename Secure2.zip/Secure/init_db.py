import sqlite3  # Module to interact with SQLite database

# Connect to database (or create if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create the users table with fields for username, password, and role
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user' NOT NULL
)
''')

# Create the comments table to store user comments
cursor.execute('''
CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    content TEXT NOT NULL
)
''')

# Commit the changes to the database
conn.commit()

# Print confirmation message to console
print("Database and tables created (if they didn't exist already).")

# Close the database connection
conn.close()
