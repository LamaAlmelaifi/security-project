# Import necessary modules from Flask and Flask-Login for web routing, session handling, and user management
from flask import Flask, render_template, request, redirect
from flask_login import LoginManager, login_user, login_required, logout_user, UserMixin, current_user
import sqlite3  # Used to interact with SQLite database
import bcrypt  # For secure password hashing
import bleach  # For sanitizing user input to prevent XSS

# Initialize Flask application
app = Flask(__name__)
app.secret_key = "securekey"  # Used to sign session cookies

# Enhance cookie security
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Disallow JavaScript access to cookies
app.config['SESSION_COOKIE_SECURE'] = True    # Use secure cookies over HTTPS

# Set up login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Redirect unauthorized users to login page

# Function to get a database connection
def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row  # Return rows as dictionaries for easier access
    return conn

# Create users and comments tables if they don't exist
with get_db_connection() as conn:
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user'
    )''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        content TEXT NOT NULL
    )''')
    conn.commit()

# User class to represent a logged-in user; inherits from Flask-Login's UserMixin
class User(UserMixin):
    def __init__(self, id, username, password, role):
        self.id = id
        self.username = username
        self.password = password
        self.role = role

# Callback to reload a user from session
@login_manager.user_loader
def load_user(user_id):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        if user:
            return User(user['id'], user['username'], user['password'], user['role'])
    return None

# Redirect root path to login page
@app.route('/')
def home():
    return redirect('/login')

# User registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password'].encode('utf-8')
        role = request.form['role']
        hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())  # Securely hash password
        try:
            with get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", 
                              (username, hashed_password, role))
                conn.commit()
            return redirect('/login')
        except sqlite3.IntegrityError:
            return "Username already exists."  # Handle duplicate usernames
    return render_template('register.html')  # Render registration form

# User login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password'].encode('utf-8')
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, password, role FROM users WHERE username = ?", (username,))
            result = cursor.fetchone()
            if result and bcrypt.checkpw(password, result['password']):
                # Create user object and log them in
                user_obj = User(result['id'], username, result['password'], result['role'])
                login_user(user_obj)
                return redirect('/dashboard')
            else:
                return render_template('login.html', error="Invalid username or password.")  # Failed login
    return render_template('login.html')  # Render login form

# Logout route, accessible only to logged-in users
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

# Dashboard route showing all comments
@app.route('/dashboard')
@login_required
def dashboard():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT username, content FROM comments")
        comments = cursor.fetchall()
    return render_template('dashboard.html', username=current_user.username, comments=comments)

# Route to handle new comment submission
@app.route('/comment', methods=['POST'])
@login_required
def comment():
    content = bleach.clean(request.form['content'])  # Sanitize comment content to prevent XSS
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO comments (username, content) VALUES (?, ?)", 
                      (current_user.username, content))
        conn.commit()
    return redirect('/dashboard')

# Admin page that lists all users; only accessible to admin role
@app.route('/admin')
@login_required
def admin():
    if current_user.role != 'admin':
        return "Access denied: Admins only.", 403  # Restrict access to admins
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT username, role FROM users")
        users = cursor.fetchall()
    return render_template('admin.html', username=current_user.username, users=users)

# Start the Flask app with HTTPS if run directly
if __name__ == '__main__':
    app.run(debug=True, ssl_context=('cert.pem', 'key.pem'))  # Enable SSL for secure HTTPS
